<!-- styling boxes for footer -->
<div id="footer">
    <div class="footer">
   
        <!-- Php echo for the footer -->
        <?php
echo "<p>Copyright &copy; 2014-" . date("Y") . " Daniels-rotbarts.com</p>";
?>
    </div>
</div>

<!-- End of the website -->
</body>

</html>