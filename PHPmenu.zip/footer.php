<div id="footer">
    <div class="footer">
   <?php
echo "<p>Copyright &copy; 2014-" . date("Y") . " Daniels-rotbarts.com</p>";
?>
    </div>
</div>
</body>

</html>