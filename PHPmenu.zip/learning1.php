<!-- Link to the external stylesheets of the page -->
<link rel="stylesheet" href="mypage.css">
 
<!-- Link to php of the menu -->
<div class="menu">
<?php include 'menu.php' ; ?>
</div>

<!-- Unique content -->
<?php echo '<h1>Learning</h1><p>Here you will get to know more about my educational growth in terms of multimedia design!</p>'
    ; ?>

<!-- Link to php of the footer -->
<?php include 'footer.php' ; ?>