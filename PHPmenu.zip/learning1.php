<link rel="stylesheet" href="mypage.css">
 <div class="menu">
<?php include 'menu.php' ; ?>
</div>

<?php echo '<h1>Learning</h1><p>Here you will get to know more about my educational growth in terms of multimedia design!</p>'
    ; ?>

<?php include 'footer.php' ; ?>