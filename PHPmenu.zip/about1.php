<link rel="stylesheet" href="mypage.css">
 <div class="menu">
<?php include 'menu.php' ; ?>
</div>

<?php echo '<h1>About</h1><p>This is my about page and here I am going to tell you a little about myself!</p>' ; ?>

<?php include 'footer.php' ; ?>