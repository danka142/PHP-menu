<!-- Link to the external stylesheets of the page -->
<link rel="stylesheet" href="mypage.css">
 
<!-- Link to php of the menu -->
<div class="menu">
<?php include 'menu.php' ; ?>
</div>

<!-- Unique content -->
<?php echo '<h1>About</h1><p>This is my about page and here I am going to tell you a little about myself!</p>' ; ?>

<!-- Link to php of the footer -->
<?php include 'footer.php' ; ?>