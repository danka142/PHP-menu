


  <?php
echo '<ul><li><a href="/page.php" class="home">Home</a></li> 
<li><a href="/about1.php" class="about">About</a></li> 
<li><a href="/learning1.php" class="learning">Learning</a></li> 
<li><a href="/projects1.php" class="projects">Projects</a></li> 
<li><a href="contact1.php" class="contact">Contact</a></li></ul>';
?>

