<!-- Link to the external stylesheets of the page -->
<link rel="stylesheet" href="mypage.css">
 
<!-- Link to php of the menu -->
<div class="menu">
<?php include 'menu.php' ; ?>
</div>

<!-- Unique content -->
<?php echo '<h1>Projects</h1>
<p>Here you will see all the progress I made in various projects and assignments!
</p>' ; ?>

<!-- Link to php of the footer -->
<?php include 'footer.php' ; ?>