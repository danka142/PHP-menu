<link rel="stylesheet" href="mypage.css">
 <div class="menu">
<?php include 'menu.php' ; ?>
</div>
<?php echo '<h1>Projects</h1>
<p>Here you will see all the progress I made in various projects and assignments!
</p>' ; ?>
<?php include 'footer.php' ; ?>