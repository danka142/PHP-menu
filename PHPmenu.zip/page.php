<!-- Link to the external stylesheets of the page -->
<link rel="stylesheet" href="mypage.css">

<!-- Link to php of the header-->
<?php include 'header.php' ; ?> 
 
<!-- Link to php of the menu -->
<div class="menu">
<?php include 'menu.php' ; ?>
</div>

<!-- Unique content -->
<h1>Website by Daniels</h1>
    <p>Welcome to the index page!</p>
    
    <p>This is a page where I use different .php files and collect them as one website.</p>
    
<!-- Link to php of the footer -->
    <?php include 'footer.php' ; ?>
