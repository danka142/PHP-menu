<!-- Link to the external stylesheets of the page -->
<link rel="stylesheet" href="mypage.css">
 
<!-- Link to php of the menu -->
<div class="menu">
<?php include 'menu.php' ; ?>
</div>

<!-- Unique content -->
<?php echo '<h1>Contact</h1><p>Here you will be able to contact me if you are interested in my works or other things.</p>' 
    ; ?>

<!-- Link to php of the footer -->
<?php include 'footer.php' ; ?>