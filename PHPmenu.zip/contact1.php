<link rel="stylesheet" href="mypage.css">
 <div class="menu">
<?php include 'menu.php' ; ?>
</div>
<?php echo '<h1>Contact</h1><p>Here you will be able to contact me if you are interested in my works or other things.</p>' 
    ; ?>
<?php include 'footer.php' ; ?>