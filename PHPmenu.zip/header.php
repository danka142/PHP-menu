<?php echo'<!DOCTYPE html>
<html>
    <head>
    <meta charset="utf-8" name="description" content="">
    <link rel="stylesheet" href="mypage.css">
        <title>Page</title>  
    </head>
<body>' ; ?> 